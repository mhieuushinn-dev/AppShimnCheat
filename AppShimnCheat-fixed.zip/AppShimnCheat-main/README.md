# Shinn Cheat iOS

Ứng dụng SwiftUI mới theo phong cách monochrome black/white glass.

## Đặc điểm

- Không Device UID
- Không Device Key
- Không License Key
- Member sử dụng miễn phí
- Owner/Admin dành cho quản trị repo
- Không có thanh tab dưới cùng
- Có Cài Đặt / Giới Thiệu / Hỗ Trợ / Gói
- Kiến trúc có thể mở rộng để đọc repo JSON

## Build local

Cài XcodeGen (`brew install xcodegen`), chạy `xcodegen generate`, rồi mở `ShinnCheat.xcodeproj` bằng Xcode và Run.

## GitHub Actions / IPA

GitHub Actions tự sinh project bằng XcodeGen rồi build ra IPA chưa ký (Actions → Artifacts). Để tạo IPA cài được trên iPhone cần Apple signing
(certificate + provisioning profile). Không commit certificate/private key vào repository.
